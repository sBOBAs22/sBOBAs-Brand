---
name: General Question
about: General Question
title: "[Question]"
labels: question
assignees: ''

---

**IMPORTANT:**
Please quickly search the existing issues and make sure that you're not create a duplicate issue. If you have a quesetion about a particular Dockerfile and deployment, change your questions to Dockerfile and post it where appropriate such as StackOverflow. This is a Docker question, not a CapRover specific issue.

--------------------------------------------------------------------------

Please clearly state your question:
