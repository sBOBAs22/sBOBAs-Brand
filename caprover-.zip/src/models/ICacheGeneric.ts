interface IHashMapGeneric<T> {
    [id: string]: T
}
