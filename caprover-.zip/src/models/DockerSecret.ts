interface DockerSecret {
    secretName: string
    secretId: string
}
