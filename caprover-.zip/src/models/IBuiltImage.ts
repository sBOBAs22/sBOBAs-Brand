export interface IBuiltImage {
    imageName: string
    gitHash: string
}
