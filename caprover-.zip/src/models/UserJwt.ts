export interface UserJwt {
    namespace: string
    tokenVersion: string
}
