# Sample Apps

Just a bunch of sample apps for you to quickly try out functionality that CapRover gives you. Most importantly, pay attention to `captain-definition` files. 

You can see more apps, such as **Django**, **Elixir/Phoenix** and **Laravel**, in our community sample apps here:

https://caprover.com/docs/sample-apps.html#community-apps
